# Scene 8 — Aftermath & Uncertain Future
## Master Shot List (Complete)

| Field | Value |
| --- | --- |
| Scene # | 8 |
| Title | Aftermath & Uncertain Future |
| INT/EXT | EXT |
| Location | Vanishing Rift |
| Time | Eternal Twilight |
| Characters | Goku (base, injured), Vegeta (base, injured), Thor (injured), Captain Marvel (injured), Hulk → Banner (unconscious) |
| Emotional beat | Exhaustion, mutual respect, relief, wonder, fragile peace, lingering tension |
| Target runtime | 0:45 |
| Continuity in | Hard cut from Scene 7.35 black / 7.33 residual sparks |
| Engine | Unreal Engine 5 |
| Aspect | 2.39:1 |
| Frame rates | 24fps throughout (no hype FPS — aftermath is weight and breath) |
| Codec plate | ARRIRAW Open Gate 8K (ref) |

**Visual notes (from bible):** near-black `#0A0A1A` / deep violet-blue `#1E1E2E`; residual cyan `#00F0FF` and gold `#FFD700` embers from Scene 7; auras **off** (base forms); Cap Binary extinguished; Stormbreaker/Mjolnir dim; Hulk reversion to Banner mid-scene. Lighting: soft low-key, smoke/haze, almost silent sound design under picture. Camera: slow, deliberate, intimate after the hyper-kinetic climax — Deakins-adjacent restraint.

---

### Beat A — Silence after white-out (0:00–0:10)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| 8.1 | 8 | Black → ELS | 18 | Locked / micro fade-up | 3 | Fade up from Scene 7 black. Vanishing Rift: dying sparks, debris settling in microgravity. No music swell yet — only ringing silence. |
| 8.2 | 8 | ELS | 25 | Very slow dolly back | 4 | Wide: five battered figures scattered on a fractured shard. Rift wound closing like a zipper of light behind them. Scale of aftermath. |
| 8.3 | 8 | WS | 35 | Locked | 3 | Smoke clears. Forms readable: orange gi, Saiyan armor, Asgardian, Cap suit (no Binary), purple pants (Hulk mid-shrink). |

### Beat B — Bodies & cost (0:10–0:24)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| 8.4 | 8 | MS | 50 | Slow push | 3 | Goku base form, kneeling then rising on one knee. Gi torn, singe marks, blood at lip. No aura. Breath visible as vapor in cold void air. |
| 8.5 | 8 | MS | 50 | Slow push (match) | 3 | Vegeta base form, standing but swaying. Armor cracked. Pride intact — he refuses to kneel. Eye flick toward Goku: rivalry still alive, softer. |
| 8.6 | 8 | MS | 47 | Handheld micro-stab | 3 | Thor: cape shredded, armor scored. Stormbreaker planted like a cane. Exhale. Weight of another cosmic war. |
| 8.7 | 8 | MS | 47 | Slow lateral | 2 | Captain Marvel: Binary gone. Suit scorched. She looks at her hands — empty of light — then at the closing rift. Relief + unfinished duty. |
| 8.8 | 8 | CU → MS | 85→50 | Pull out | 3 | Hulk shrinking to Banner: green drains, body collapses. Cap or Thor (whichever closest) steps half a pace — no dialogue, just presence. Banner unconscious. |

### Beat C — Mutual recognition (0:24–0:38)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| 8.9 | 8 | OTS | 75 | Locked | 3 | Over Goku’s shoulder: Thor across the shard. Eye contact. New respect without words. |
| 8.10 | 8 | OTS | 75 | Locked | 3 | Over Thor’s shoulder: Goku. Almost-friendly nod begins (bible beat). Vegeta in soft background, arms crossed, acknowledging without smiling. |
| 8.11 | 8 | ECU | 150 | Static | 2 | Goku’s nod completes — small, tired, sincere. |
| 8.12 | 8 | ECU | 150 | Static | 2 | Thor’s return nod — regal, brief. Shared understanding of “we could have destroyed each other.” |
| 8.13 | 8 | MS two-shot | 50 | Subtle arc | 4 | Cap and Vegeta share a glance: warrior-to-warrior. Cap’s chin tip; Vegeta’s scoff that is almost respect. |

### Beat D — Separation & uncertain future (0:38–0:45)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| 8.14 | 8 | WS | 35 | Slow push toward closing rift | 3 | Rift seals to a hairline, then nothing. Universes begin to pull apart — shard cracks along a glowing seam (MCU side / Universe 7 side). |
| 8.15 | 8 | ELS | 18 | Dolly back + slight rise | 3 | Heroes split across the seam as realities restore. Fleeting acknowledgment across the gap (bible Act III). Then each side dissolves to their own sky. |
| 8.16 | 8 | Hold / title air | 25 | Locked | 1 | Optional last frame: empty twilight where the rift was — one cyan spark, one gold spark, extinguish. Cut to black / end card. |
| 8.17 | 8 | Buffer / safety | 25 | Locked | 2 | Clean plates: (a) empty Vanishing Rift, (b) Banner unconscious alone, (c) sealed sky with no heroes. Not in dramatic runtime. |

---

### Timing roll-up (dramatic picture)

| Beat | Shots | Approx. duration |
| --- | --- | --- |
| A Silence after white-out | 8.1–8.3 | 10s |
| B Bodies & cost | 8.4–8.8 | 14s |
| C Mutual recognition | 8.9–8.13 | 14s |
| D Separation & future | 8.14–8.16 | 7s |
| **Total** | **8.1–8.16** | **~45s** |

### Continuity & VFX flags

1. **No dialogue** — Scene 8 is pure look / breath / nod (matches Scene 7 silence language).
2. **Power state:** all auras off; Cap not Binary; Goku/Vegeta black hair base; Hulk → Banner completes by 8.8.
3. **Injury readable but not gore** — singe, tears, blood at lip, cracked armor.
4. **Axis handoff from Scene 7:** heroes were arc facing Scourge screen-right; aftermath redistributes them on a shared shard, then splits MCU (screen-right fade) vs Universe 7 (screen-left fade).
5. **Rift:** only closes in Beat D; keep it visible and dying through Beats A–C for geographic continuity with 7.33.
6. **Sound:** near-silence → distant debris ticks → single low string on Goku/Thor nod → vacuum whoosh on seam split → true silence on 8.16.
7. **Do not** reopen fight energy, Instant Transmission flourishes, or Binary flare — aftermath stays grounded.
8. **Banner care:** Cap or Thor proximity only; no medical dialogue; unconscious status holds into credits world.

### Coverage extras (optional pickups)

| # | Shot type | Lens | Dur | Notes |
| --- | --- | --- | --- | --- |
| 8.A | High ELS top-down | 18 | 3 | God-view of five spent bodies on the shard — trailer “cost of victory” plate. |
| 8.B | Insert Stormbreaker | 100 | 1.5 | Weapon planted, lightning dead — power spent. |
| 8.C | Insert Goku fist unclenching | 150 | 1.5 | Softens warrior stance into peace. |
| 8.D | Reverse across gap | 75 | 2 | Each universe’s sky (Earth dusk / Beerus-planet stars) for the separation beat. |

---

*Source: GPP-Core Mk VII production bible — Dragon Ball Super × Avengers — Full-Pace Fight. Scene 8 complete pass; aligns Scene 8 summary (0:45) with Act III aftermath (silent acknowledgment, realities separate, uncertain future).*
