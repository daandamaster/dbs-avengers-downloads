# Scene 7 — United Attack & Catastrophic Climax
## Master Shot List (Complete)

| Field | Value |
| --- | --- |
| Scene # | 7 |
| Title | United Attack & Catastrophic Climax |
| INT/EXT | EXT |
| Location | Heart of the Rift |
| Time | Eternal Twilight |
| Characters | Goku (SSB + Kaioken ×20), Vegeta (SSB Evolved), Thor (Mjolnir + Stormbreaker), Captain Marvel (Binary), Hulk (Worldbreaker); antagonist: Aetherial Scourge |
| Support (bg / VFX) | Dimensional expulsion vortex (Strange/Whis continuity from Act III) — present as environment, not dialogue |
| Emotional beat | Desperation, ultimate power, self-sacrifice, explosive climax, universal stakes |
| Target runtime | 2:00 |
| Engine | Unreal Engine 5 |
| Aspect | 2.39:1 |
| Frame rates | 24fps base; 48–60fps for beam travel; up to 120fps for impact / transformation inserts |
| Codec plate | ARRIRAW Open Gate 8K (ref) |

**Visual notes (from bible):** Scourge = shifting dark energy, magenta/void black; Goku Kaioken overlay `#FF0000` on `#00F0FF`; Vegeta Evolved `#3366FF`/`#8A2BE2`; Thor `#ADD8E6`/`#FFD700`; Cap Binary `#FFD700`/`#FF4500`; Hulk `#008000`/`#32CD32`; combined impact `#FFFFFF` / `#FF00FF` / `#00FFFF`. Lighting: character auras as primary practicals; extreme backlight; volumetric haze. Camera: hyper-kinetic, gravity-defying, anime whip/snap language fused with photoreal VFX.

---

### Beat A — Heart of the Rift / Scourge primed (0:00–0:15)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | FPS | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7.1 | 7 | ELS | 18 | Crane down into rift | 4 | 24 | Enter Heart of the Rift: impossible geometries, bleeding Asgard/Namek/Earth fragments. Scourge core as a pulsing void-star. |
| 7.2 | 7 | LS | 25 | Orbit clockwise slow | 3 | 24 | Scourge fully manifest — amorphous, tendrils anchoring to three collapsed dimensional scars. Sucks light. |
| 7.3 | 7 | WS | 35 | Push toward heroes | 3 | 24 | Five heroes in a loose arc facing the core. Exhausted but set. Vortex ring faintly opens behind Scourge (Strange/Whis work — silhouette only). |
| 7.4 | 7 | CU montage | 125 | Smash cuts ×5 | 5 | 24 | Rapid CU: Goku grit → Vegeta snarl → Thor roar → Cap Binary eyes → Hulk Worldbreaker snarl. 1s each. No words. |

### Beat B — Charge & formation (0:15–0:40)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | FPS | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7.5 | 7 | MS | 47 | Dolly circle Goku | 4 | 24→48 | Goku drops into stance; Kaioken ×20 ignites over SSB — crimson veins through cyan aura. Heat shimmer. |
| 7.6 | 7 | MS | 47 | Dolly reverse Vegeta | 3 | 24 | Vegeta SSB Evolved: purple-cobalt flare; Final Flash charge builds between palms. Pride over fear. |
| 7.7 | 7 | LS | 24 | Crane up with Thor | 4 | 48 | Thor rises, dual-wield Mjolnir + Stormbreaker. Calls cosmic lightning — Bifrost-tinged storm column. |
| 7.8 | 7 | MS → CU | 75→150 | Push to Cap | 3 | 24 | Captain Marvel goes full Binary — body becomes gold/orange light. Photonic corona expands. |
| 7.9 | 7 | LS | 35 | Low angle up at Hulk | 3 | 24 | Worldbreaker Hulk plants feet on a crystalline shard; ground fractures in green shock-rings. Thunderclap wind-up. |
| 7.10 | 7 | WS | 25 | Steadicam arc wide | 4 | 24 | All five charging simultaneously; color-coded auras paint the rift. Scourge recoils, tendrils bristling. |
| 7.11 | 7 | ECU | 150 | Static | 2 | 120 | Extreme slow: Goku’s pupils shrink; Kaioken flicker frame-by-frame. |
| 7.12 | 7 | ECU | 150 | Static | 2 | 120 | Extreme slow: Stormbreaker edge sparks; Cap’s iris floods gold. |

### Beat C — Unleash (individual signatures) (0:40–1:10)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | FPS | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7.13 | 7 | MS | 50 | Handheld track with beam | 4 | 60 | Goku: Super Kamehameha (Kaioken-boosted) — wide cyan-crimson beam. Camera rides beside the beam. |
| 7.14 | 7 | MS | 50 | Parallel track | 3 | 60 | Vegeta: Final Flash — gold-white lance, tighter than Kamehameha, faster travel. |
| 7.15 | 7 | LS | 24 | Whip pan into Thor | 4 | 48 | Thor: dual-weapon overhead strike → projected lightning spear into Scourge. Sonic boom rings. |
| 7.16 | 7 | LS | 35 | Dolly in Binary flight | 4 | 60 | Cap flies beam-path, continuous photon output as a solid column of gold-orange. |
| 7.17 | 7 | MS | 47 | Crash-in on clap | 3 | 120 | Hulk thunderclap: shockwave visualized as green concentric rings + debris hurricane. Play at 24 for weight. |
| 7.18 | 7 | ELS | 18 | Locked / micro push | 5 | 24 | All five attacks visible as converging vectors toward Scourge core. Scale shot — heroes tiny, beams planetary. |
| 7.19 | 7 | CU | 85 | Snap zoom Scourge | 3 | 24 | Scourge “face” (shifting voids) absorbs first contact — cracks of white light appear in its mass. |
| 7.20 | 7 | Insert / split | 35 | Intercut 4×0.5s | 2 | 48 | Heroes straining: arms shaking, auras spiking, teeth clenched. |

### Beat D — Convergence & beam struggle (1:10–1:40)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | FPS | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7.21 | 7 | WS | 35 | Orbit 180° | 5 | 24 | Beams braid into a single multicolor spear (cyan/crimson/cobalt/gold/green/lightning). Classic anime “clash” geometry, photoreal materials. |
| 7.22 | 7 | MS | 75 | Push along braid | 4 | 60 | Ride the combined beam toward Scourge; chromatic aberration spikes at energy seams. |
| 7.23 | 7 | CU | 100 | Handheld chaos (controlled) | 3 | 24 | Impact face: Scourge vs braid — push/pull. Inch-by-inch toward expulsion vortex. |
| 7.24 | 7 | OTS | 50 | Locked | 3 | 24 | Over Goku/Vegeta: seeing Cap + Thor + Hulk contribute from flanks — true alliance visual. |
| 7.25 | 7 | ELS | 18 | Dutch roll toward tear | 4 | 24 | Reality buckling: Heart of the Rift folding; debris orbits the struggle like a galaxy. |
| 7.26 | 7 | CU montage | 125 | Smash ×4 | 4 | 120 | Desperation inserts (0.8–1s each @120 played slow): Goku Kaioken veins; Vegeta blood-tear pride; Thor scream; Cap Binary flare overload. |
| 7.27 | 7 | LS | 24 | Crash zoom out | 3 | 24 | Scourge surges — dark tendril tries to drag heroes into void. Heroes dig in; combined output spikes blinding white. |
| 7.28 | 7 | ECU | 150 | Static | 2 | 120 | Point of contact: white core forming — “weak point” from treatment. Hold. |
| 7.29 | 7 | WS | 25 | Dolly rush toward core | 2 | 48 | All power commits — no reserve left. Screen fills with light. |

### Beat E — Cataclysm & expulsion (1:40–1:55)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | FPS | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7.30 | 7 | ELS | 12–18 | Locked plate → shake | 4 | 24 | Cataclysmic explosion: Scourge ripped apart into the expulsion vortex. White-out with magenta shock-rings. Planetary debris blasted outward. |
| 7.31 | 7 | Abstract | — | Optical / CG only | 3 | 24 | Pure energy field: no horizon. Silhouettes of five heroes briefly readable inside the blast, then lost. |
| 7.32 | 7 | LS | 35 | Whip through debris | 3 | 60 | Scourge remnants sucked into vortex; vortex snaps shut with a silent compression (sound design: vacuum pop). |
| 7.33 | 7 | ELS | 18 | Slow pull back | 3 | 24 | Heart of the Rift collapsing; light dying to eternal twilight. End on almost-black with residual cyan/gold sparks. Hard cut → Scene 8. |
| 7.34 | 7 | Buffer / safety | 25 | Locked | 2 | 24 | Clean plates: (a) Scourge hero-less, (b) empty Heart, (c) pure white flash — editorial/VFX. Not in dramatic runtime. |

### Beat F — Editorial bridge (optional 1:55–2:00)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | FPS | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 7.35 | 7 | Black | — | Hold | 2 | 24 | 2s black / ringing silence before Scene 8 aftermath — recommended cut point. |
| 7.36 | 7 | ECU eye | 150 | Fade up from black | 3 | 24 | Optional open-to-8: Goku’s eye opens (base form, injured) — only if editor wants Scene 7 to own the first aftermath frame. Else leave for 8.1. |

---

### Timing roll-up (dramatic picture)

| Beat | Shots | Approx. duration |
| --- | --- | --- |
| A Heart / primed | 7.1–7.4 | 15s |
| B Charge & formation | 7.5–7.12 | 25s |
| C Unleash signatures | 7.13–7.20 | 30s |
| D Convergence / struggle | 7.21–7.29 | 30s |
| E Cataclysm / expulsion | 7.30–7.33 | 13s |
| F Bridge / black | 7.35 (±7.36) | 2–5s |
| **Total** | **7.1–7.33 + 7.35** | **~115–120s** |

### Attack order (picture continuity)

1. Goku Super Kamehameha (Kaioken ×20)  
2. Vegeta Final Flash (overlap +0.5s)  
3. Thor dual-weapon lightning spear  
4. Captain Marvel Binary column  
5. Hulk thunderclap shockwave (last — clears debris path / adds green ring into the braid)  
6. Braid lock → push Scourge into Strange/Whis vortex → white-out  

### Continuity & VFX flags

1. **No dialogue** in Scene 7 picture cut — emotional beat is pure performance + power.
2. **Kaioken ×20** must read as crimson lattice *over* SSB cyan; never replace cyan entirely.
3. **Dual Thor weapons** both on-screen in 7.7 and 7.15; lightning color `#ADD8E6` + gold accents.
4. **Binary Cap** is a light-source practical for everyone in frame during Beat C–D.
5. **Scourge damage language:** absorb → crack white → braid push → shred into vortex (never a simple “HP bar” explode).
6. **Vortex:** present from 7.3 as faint ring; only fully active in Beat E — matches Act III Strange/Whis expulsion.
7. **Axis:** heroes hold a shallow arc screen-left/center; Scourge + vortex screen-right/deep — preserve until white-out.
8. **120fps inserts** (7.11, 7.12, 7.17, 7.26, 7.28) are mandatory for trailer & impact clarity.
9. **Sound:** build sub-bass under Beat B; full orchestra + choir hit on 7.21 braid; near-silence on 7.32 vortex snap; true silence on 7.35.
10. **Scene 8 handoff:** heroes injured/base forms live in Scene 8 — do not resolve character status inside 7 except as silhouettes in the blast.

### Coverage extras (optional pickups)

| # | Shot type | Lens | Dur | Notes |
| --- | --- | --- | --- | --- |
| 7.A | Top-down ELS | 18 | 4 | God-view of five beams + Scourge — trailer hero plate. |
| 7.B | Macro CU braid | 100 macro | 2 | Energy filament detail for motion graphics / title sting. |
| 7.C | Reverse POV Scourge | 24 | 3 | Looking “out” at heroes through void-distortion — horror beat. |
| 7.D | Hulk feet insert | 85 | 1.5 | Crystalline shard exploding under Worldbreaker stance. |
| 7.E | Cap hand ECU | 150 | 1.5 | Photons leaving palm as solid geometry. |

---

*Source: GPP-Core Mk VII production bible — Dragon Ball Super × Avengers — Full-Pace Fight. Scene 7 complete pass; aligns Scene 7 summary (2:00) with Act III climax mechanics (combined assault + expulsion vortex).*
