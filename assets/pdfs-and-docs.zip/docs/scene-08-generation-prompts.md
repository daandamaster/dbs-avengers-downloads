# Scene 8 — Key Stills Generation Pack (Complete)
## GPP-Core Mk VII · Dragon Ball Super × Avengers — Full-Pace Fight

| Field | Value |
| --- | --- |
| Scene | 8 — Aftermath & Uncertain Future |
| Aspect | 2.39:1 (generate 16:9, crop to scope in post) |
| Look | Photoreal cinematic; quiet aftermath after hyper-kinetic climax; soft low-key; auras OFF; Unreal Engine 5 |
| Negative (global) | text, watermark, logo, UI, glowing power auras, Binary form, Super Saiyan hair, fight poses, extra limbs, low-res |

### Global style block (append to every prompt)

```
Cinematic still from an epic sci-fi superhero martial-arts crossover film, aftermath beat, 2.39:1 anamorphic scope framing, photoreal VFX, soft low-key lighting, volumetric haze and smoke, deep space near-black #0A0A1A and deep violet-blue #1E1E2E, residual cyan #00F0FF and gold #FFD700 embers only, no character power auras, exhausted wounded heroes, Unreal Engine 5 cinematic render, IMAX-quality detail, quiet emotional weight, no text, no watermark
```

---

## KEY STILL PROMPTS

### KS-8.01 — Silence after white-out
**Maps to:** 8.1–8.2 · Beat A

```
Extreme long shot of a vanishing interdimensional rift after a cosmic battle: dying cyan and gold sparks, debris settling in microgravity, five tiny battered silhouettes on a fractured cosmic shard, the rift wound closing like a zipper of light, ringing silence visual, [GLOBAL STYLE BLOCK]
```

### KS-8.02 — Five spent on the shard
**Maps to:** 8.3 · Beat A

```
Wide cinematic shot of five exhausted wounded warriors on a cracked floating shard in eternal twilight: orange-gi martial artist black hair base form, shorter armored Saiyan prince black hair, towering blond Asgardian with shredded red cape, athletic woman in scorched dark-blue red gold suit without energy glow, colossal green giant mid-shrink toward a smaller human form, smoke clearing, [GLOBAL STYLE BLOCK]
```

### KS-8.03 — Goku base, injured
**Maps to:** 8.4 · Beat B

```
Medium shot of base-form Goku after battle: black spiky hair not glowing, battle-worn torn orange gi with singe marks, blood at lip, rising on one knee, no aura, breath as vapor in cold void air, exhausted but alive, Heart of the Rift debris soft bokeh, [GLOBAL STYLE BLOCK]
```

### KS-8.04 — Vegeta base, pride unbroken
**Maps to:** 8.5 · Beat B

```
Medium shot of base-form Vegeta after battle: black upright spiky hair, cracked dark-blue Saiyan armor, standing but swaying, refuses to kneel, no aura, proud exhausted snarl softening, [GLOBAL STYLE BLOCK]
```

### KS-8.05 — Thor spent
**Maps to:** 8.6 · Beat B

```
Medium shot of Thor after cosmic war: long golden-blond hair, ornate blue-silver-gold armor scored and battered, shredded red cape, Stormbreaker planted like a cane, no lightning, heavy exhale, low-key rim light, [GLOBAL STYLE BLOCK]
```

### KS-8.06 — Cap without Binary
**Maps to:** 8.7 · Beat B

```
Medium shot of Captain Marvel after Binary ends: short blonde hair, scorched dark-blue red gold suit, no photonic corona, looking at empty hands then toward a closing dimensional rift, relief and unfinished duty, soft practical light only, [GLOBAL STYLE BLOCK]
```

### KS-8.07 — Hulk reverts to Banner
**Maps to:** 8.8 · Beat B

```
Cinematic medium shot of Hulk shrinking into unconscious Bruce Banner: green draining from skin, body collapsing on a crystalline shard, nearby a battered blond Asgardian or cosmic hero stepping half a pace closer in silent care, no dialogue energy, [GLOBAL STYLE BLOCK]
```

### KS-8.08 — Goku ↔ Thor nod
**Maps to:** 8.9–8.12 · Beat C

```
Over-the-shoulder cinematic two-shot across a shattered cosmic shard: exhausted base-form martial artist in torn orange gi and a battered Asgardian god locking eyes, almost-friendly tired nods of mutual respect, no auras, quiet aftermath, shallow depth of field, [GLOBAL STYLE BLOCK]
```

### KS-8.09 — Cap ↔ Vegeta glance
**Maps to:** 8.13 · Beat C

```
Medium two-shot: scorched cosmic hero woman without Binary glow and proud Saiyan prince in cracked armor sharing a warrior-to-warrior glance, her chin tip, his almost-respectful scoff, exhausted, no energy auras, [GLOBAL STYLE BLOCK]
```

### KS-8.10 — Realities separate
**Maps to:** 8.14–8.15 · Beat D

```
Extreme long shot of a glowing seam cracking a cosmic shard in two as universes pull apart: battered heroes splitting to opposite sides, fleeting acknowledgment across the gap, each side dissolving toward different skies — Earth dusk one side, alien starfield the other — closing rift gone, [GLOBAL STYLE BLOCK]
```

### KS-8.11 — Empty twilight bridge
**Maps to:** 8.16 · Beat D

```
Quiet extreme long shot of empty eternal twilight where an interdimensional rift used to be: vast negative space, one dying cyan spark and one dying gold spark extinguishing, fragile peace after cosmic violence, cinematic stillness, [GLOBAL STYLE BLOCK]
```

### KS-8.12 — Cost of victory (trailer plate)
**Maps to:** 8.A pickup

```
High extreme long top-down god-view of five spent bodies on a fractured cosmic shard after battle, smoke and residual embers, no power glows, trailer “cost of victory” plate, [GLOBAL STYLE BLOCK]
```

---

## TRAILER CUTDOWN SET (priority render order)

1. KS-8.08 Goku ↔ Thor nod  
2. KS-8.01 Silence after white-out  
3. KS-8.10 Realities separate  
4. KS-8.02 Five spent on the shard  
5. KS-8.11 Empty twilight  
6. KS-8.03 / 8.05 hero cost close-ups  

## File naming

```
KS-8.01_silence-after-whiteout.png
KS-8.02_five-spent-on-shard.png
KS-8.03_goku-base-injured.png
KS-8.04_vegeta-base-pride.png
KS-8.05_thor-spent.png
KS-8.06_cap-without-binary.png
KS-8.07_hulk-to-banner.png
KS-8.08_goku-thor-nod.png
KS-8.09_cap-vegeta-glance.png
KS-8.10_realities-separate.png
KS-8.11_empty-twilight.png
KS-8.12_cost-of-victory.png
```

*Complete Scene 8 generation pack — 12 key stills.*
