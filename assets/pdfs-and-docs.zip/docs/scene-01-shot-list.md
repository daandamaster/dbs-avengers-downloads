# Scene 1 — The Cosmic Rift
## Master Shot List (Complete)

| Field | Value |
| --- | --- |
| Scene # | 1 |
| Title | The Cosmic Rift |
| INT/EXT | EXT |
| Location | Void Between Dimensions |
| Time | Eternal Twilight |
| Characters | Goku (SSB), Vegeta (SSB), Thor, Captain Marvel |
| Emotional beat | Awe, tension, foreboding, readiness for conflict |
| Target runtime | 0:45 |
| Engine | Unreal Engine 5 |
| Aspect | 2.39:1 |
| Codec plate | ARRIRAW Open Gate 8K (ref) |

**Visual notes (from bible):** deep space `#0A0A1A` / `#1E1E2E`; nebula purples & blues; Goku aura `#00F0FF`; Vegeta aura `#3366FF`; Thor lightning `#ADD8E6`/`#FFD700`; Captain Marvel `#FFD700`/`#FF4500`; cosmic impacts `#FFFFFF`/`#FF00FF`/`#00FFFF`. Camera language: hyper-kinetic tracking, whip pans, snap zooms, gravity-defying perspectives.

---

### Beat A — Nascent tear (0:00–0:08)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Engine | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1.1 | 1 | ELS | 18 | Dolly in / crane up | 5 | UE5 | Cosmic void. Nascent dimensional tear as a hairline fracture of white-magenta light. Galactic dust drifts toward the seam. Deep purples & blues. No characters. |
| 1.2 | 1 | ELS → LS | 25 | Slow push + slight roll | 3 | UE5 | Tear widens. Debris (asteroid shards, frozen gas) accelerates into the rift. Volumetric god-rays through haze. Subtle lens flare from the tear’s core. |

### Beat B — Dual arrival (0:08–0:20)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Engine | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1.3 | 1 | LS | 24 | Whip pan L→R | 3 | UE5 | Goku & Vegeta materialize from a light-burst (Whis-teleport energy, gold-white). Backlit. Eyes narrow. SSB auras ignite on settle. |
| 1.4 | 1 | MS | 47 | Handheld micro-stabilize | 2 | UE5 | Vegeta’s sneer; armor plates catch cyan rim light. He scans left, sensing foreign power. |
| 1.5 | 1 | LS | 24 | Whip pan R→L | 3 | UE5 | Thor (Stormbreaker) & Captain Marvel arrive through a Bifrost-tinged / photon streak. Opposing axis to 1.3. Cap’s energy channels glow. |
| 1.6 | 1 | MS | 47 | Push in | 2 | UE5 | Thor’s grip tightens on Stormbreaker; Mjolnir hum (if carried) or Stormbreaker arcs. Soft gold rim from Cap behind him. |
| 1.7 | 1 | CU | 125 | Snap zoom settle | 2 | UE5 | Captain Marvel’s eyes: stern assessment. Binary glow builds under the skin of her cheekbones. Shallow DOF, tear bokeh behind. |

### Beat C — Power recognition (0:20–0:34)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Engine | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1.8 | 1 | MS | 50 | Push in | 3 | UE5 | Goku’s determined, wary face. SSB aura pulses `#00F0FF`. Ki sense — slight eye twitch toward Thor. |
| 1.9 | 1 | MS | 50 | Push in (match cut energy) | 3 | UE5 | Thor’s serious assessing gaze. Lightning micro-arcs on armor. Mutual recognition of “not ordinary foe.” |
| 1.10 | 1 | OTS | 75 | Locked / subtle drift | 2 | UE5 | Over Goku’s shoulder: Thor & Cap silhouetted against the tear. Scale contrast — gods vs Saiyans across debris field. |
| 1.11 | 1 | OTS | 75 | Locked / subtle drift | 2 | UE5 | Over Thor’s shoulder: Goku & Vegeta, auras reading as alien energy signatures. Vegeta steps half a pace forward. |
| 1.12 | 1 | CU insert | 150 | Static | 1.5 | UE5 | Extreme CU: Mjolnir / Stormbreaker head humming; dust vibrating off the metal. |
| 1.13 | 1 | CU insert | 150 | Static | 1.5 | UE5 | Extreme CU: Goku’s fist closes; knuckles flex; aura compresses tighter around the wrist. |
| 1.14 | 1 | MS | 35 | Crane orbit ¼ circle | 3 | UE5 | Vegeta and Captain Marvel lock eyes across frame. Galick-ready stance vs photon stance. Tension without contact. |

### Beat D — Standoff hold (0:34–0:45)

| # | Scene | Shot type | Lens (mm) | Movement | Dur (s) | Engine | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1.15 | 1 | WS | 35 | Steadicam arc | 5 | UE5 | Four figures in a tense, balanced diamond standoff amid cosmic debris. Tear behind them as a vertical wound of light. Auras and lightning rim-light each silhouette. |
| 1.16 | 1 | ELS | 18 | Slow dolly back | 3 | UE5 | Pull to extreme wide: tiny figures vs vast void and expanding rift. Sound design cue: silence under a rising sub-bass. Foreshadow Scene 2. |
| 1.17 | 1 | ECU | 150 | Snap in / hold | 2 | UE5 | Smash cut to Goku’s eye (iris flare cyan) OR Thor’s eye (storm reflection) — choose in edit; holds 2s then hard cut to Scene 2. |
| 1.18 | 1 | Buffer / safety | 25 | Locked plate | 1 | UE5 | Clean plate of void + tear only (no heroes) for VFX / editorial coverage. Optional; not counted in dramatic runtime. |

---

### Timing roll-up (dramatic picture)

| Beat | Shots | Approx. duration |
| --- | --- | --- |
| A Nascent tear | 1.1–1.2 | 8s |
| B Dual arrival | 1.3–1.7 | 12s |
| C Power recognition | 1.8–1.14 | 14s |
| D Standoff hold | 1.15–1.17 | 10s |
| **Total** | **1.1–1.17** | **~44s** (+1.18 safety plate) |

### Continuity & VFX flags

1. **Rift growth:** tear width increases every beat (hairline → visible wound → vertical scar behind the diamond).
2. **Axis:** Universe 7 arrives screen-left; MCU arrives screen-right; keep 180° until Scene 2 first contact.
3. **Aura vs lightning:** SSB cyan/cobalt never reads as Cap binary gold/orange — color grade separation per bible hexes.
4. **Debris:** same asteroid field continuity; pieces drift toward tear in all wides.
5. **No contact / no blast yet:** Scene 1 is standoff only; first punch lives in Scene 2 (shot 2.1+).
6. **Sound:** windless void until 1.15; then layered ki hum + Asgardian thunder underhold into Scene 2 whip.

### Coverage extras (optional pickups)

| # | Shot type | Lens | Dur | Notes |
| --- | --- | --- | --- | --- |
| 1.A | High ELS top-down | 18 | 3 | God-view of diamond standoff; useful for trailer cutdowns. |
| 1.B | Dutch angle WS | 35 | 2 | Reality already “wrong” — slight roll toward tear. |
| 1.C | Macro CU rift edge | 100 macro | 2 | Fractured spacetime texture for motion-graphics / title card. |

---

*Source: GPP-Core Mk VII production bible — Dragon Ball Super × Avengers — Full-Pace Fight. Scene 1 complete pass replaces partial master rows 1.1–1.6.*
