GPP-Core Mk VII — Dragon Ball Super x Avengers — Full-Pace Fight
Download pack contents
======================

PDFs (deliverables/)
- GPP-Core-MkVII_Complete-Production.pdf
    Original production bible + Scene 1/7/8 shot lists + generation prompts
- GPP-Core-MkVII_DBS-x-Avengers_Production-Bible.pdf
    Original bible only
- GPP-Core-MkVII_Expanded_Shotlists-and-Prompts.pdf
    Expanded shot lists + prompts only

Shot lists & prompts (markdown / json)
- scene-01-shot-list.md
- scene-07-shot-list.md
- scene-07-generation-prompts.md
- scene-08-shot-list.md
- scene-08-generation-prompts.md
- scene-01-prompts.json
- scene-08-prompts.json

Stills
- scene-01-stills/   SHOT-1.01 … SHOT-1.17 (17)
- scene-07-stills/   KS-7.01 … KS-7.16 (16)
- scene-08-stills/   (not generated yet — interrupted)

Note: Scene 8 key stills and remaining Scene 7 individual shot fills were not finished when this pack was built.
