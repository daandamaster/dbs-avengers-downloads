# Scene 7 — Key Stills Generation Pack (Complete)
## GPP-Core Mk VII · Dragon Ball Super × Avengers — Full-Pace Fight

| Field | Value |
| --- | --- |
| Scene | 7 — United Attack & Catastrophic Climax |
| Aspect | 2.39:1 (generate at 16:9, crop to scope in post) |
| Look | Photoreal cinematic VFX + anime kineticism; Unreal Engine 5 quality; ARRIRAW-grade color depth |
| Negative (global) | text, watermark, logo, UI, comic panel borders, low-res, blurry faces, extra limbs, deformed hands, childish cartoon flat shading |

### Global style block (append to every prompt)

```
Cinematic still from an epic sci-fi superhero martial-arts crossover film, 2.39:1 anamorphic scope framing, photoreal VFX fused with anime kinetic energy, extreme dynamic lighting, volumetric god-rays and haze, deep space near-black #0A0A1A and deep violet-blue #1E1E2E, high contrast hard key light, aura and energy blasts as practical light sources, Unreal Engine 5 cinematic render, IMAX-quality detail, no text, no watermark
```

### Color locks

| Element | Hex |
| --- | --- |
| Goku SSB / Kaioken | `#00F0FF` + `#FF0000` lattice |
| Vegeta SSB Evolved | `#3366FF` + `#8A2BE2` |
| Thor lightning | `#ADD8E6` + `#FFD700` |
| Cap Binary | `#FFD700` + `#FF4500` |
| Hulk | `#008000` + `#32CD32` |
| Cosmic impact | `#FFFFFF` `#FF00FF` `#00FFFF` |
| Scourge | void black + magenta bleed |

---

## KEY STILL PROMPTS

### KS-7.01 — Heart of the Rift / Scourge primed
**Maps to:** 7.1–7.2 · Beat A  
**Camera:** ELS 18mm, crane-down energy

```
Extreme long shot looking down into the Heart of an interdimensional rift: impossible fractured geometries, bleeding fragments of alien cityscapes and planetary crust floating in a void, at center a colossal amorphous Aetherial Scourge as a pulsing void-star of dark swirling energy with magenta edges, tendrils anchoring into dimensional scars, sucking light from the scene, cosmic debris orbiting inward, [GLOBAL STYLE BLOCK]
```

### KS-7.02 — Five heroes formation
**Maps to:** 7.3 · Beat A  
**Camera:** WS 35mm push

```
Wide cinematic shot of five exhausted but resolute warriors in a shallow arc facing a dark cosmic entity: left-to-right a spiky-haired Saiyan in orange gi with electric cyan aura, a shorter proud Saiyan in sleek dark-blue armor with cobalt-purple aura, a towering Asgardian god in ornate blue-silver-gold armor dual-wielding a hammer and a glowing axe, a female cosmic hero in dark blue red gold suit glowing gold-orange Binary energy, and a colossal green Worldbreaker Hulk, behind them a faint circular dimensional expulsion vortex ring, Heart of the Rift environment, [GLOBAL STYLE BLOCK]
```

### KS-7.03 — Hero resolve montage plate
**Maps to:** 7.4 · Beat A  
**Camera:** CU 125mm (composite plate or 5-panel strip)

```
Ultra-close cinematic portrait montage energy: five intense faces side by side in one epic still as if smash-cut frames — determined Saiyan fighter with cyan aura rim light, arrogant Saiyan prince snarling with purple-cobalt light, roaring Asgardian with lightning reflections in eyes, stern Binary-powered woman with gold glow under cheekbones, Worldbreaker Hulk snarl with emerald rim — shallow depth of field, [GLOBAL STYLE BLOCK]
```

### KS-7.04 — Goku Kaioken ×20 charge
**Maps to:** 7.5 / 7.11 · Beat B  
**Camera:** MS 47mm dolly circle

```
Medium shot of Super Saiyan Blue Goku mid-charge: muscular fighter in battle-worn orange gi, spiky glowing cyan hair, electric blue aura #00F0FF with intense crimson Kaioken ×20 lattice veins of red energy crawling over the cyan, heat shimmer, fists drawn back for a Kamehameha, face gritted and determined, Heart of the Rift debris bokeh behind, hard directional key, [GLOBAL STYLE BLOCK]
```

### KS-7.05 — Vegeta Final Flash wind-up
**Maps to:** 7.6 · Beat B  
**Camera:** MS 47mm

```
Medium shot of Super Saiyan Blue Evolved Vegeta: shorter hyper-muscular Saiyan prince in sleek futuristic dark-blue armor white gloves boots, upright spiky glowing hair, cobalt blue #3366FF and amethyst purple #8A2BE2 aura flaring, palms apart charging a gold-white Final Flash lance of energy, proud snarl, battle scars on armor, rift chaos behind, [GLOBAL STYLE BLOCK]
```

### KS-7.06 — Thor dual-weapon storm
**Maps to:** 7.7 / 7.15 · Beat B–C  
**Camera:** LS 24mm crane up

```
Long shot of Thor Odinson rising in battle: towering muscular Asgardian, long golden-blond hair, ornate deep-blue silver gold Asgardian armor with red cape, dual-wielding Mjolnir and Stormbreaker both crackling with light-blue #ADD8E6 and gold #FFD700 lightning, calling a Bifrost-tinged storm column from the void, low angle heroic, volumetric lightning bolts, [GLOBAL STYLE BLOCK]
```

### KS-7.07 — Captain Marvel Binary
**Maps to:** 7.8 / 7.16 · Beat B–C  
**Camera:** MS→CU 75–150mm

```
Cinematic medium-close of Captain Marvel in full Binary form: athletic woman, short blonde hair, dark-blue red gold Kree Starforce suit with glowing energy channels, entire body radiating gold #FFD700 and orange-red #FF4500 photonic corona, eyes blazing, flying forward as a solid column of light begins to form from her palms, she is the practical light source illuminating cosmic debris, [GLOBAL STYLE BLOCK]
```

### KS-7.08 — Hulk Worldbreaker thunderclap
**Maps to:** 7.9 / 7.17 · Beat B–C  
**Camera:** LS 35mm low angle + clap insert energy

```
Low-angle long shot of Worldbreaker Hulk: colossal intensely muscular green giant, tattered durable pants, feet planted on a cracking crystalline cosmic shard sending emerald #008000 and lime #32CD32 shock-rings through the ground, mid thunderclap with palms about to collide, hurricane of debris blasting outward, rage controlled and immense, Heart of the Rift verticality, [GLOBAL STYLE BLOCK]
```

### KS-7.09 — Signature beams unleashed (suite plate)
**Maps to:** 7.13–7.17 · Beat C  
**Camera:** ELS composite energy

```
Epic wide still showing five simultaneous signature attacks mid-flight toward a dark void entity: a wide cyan-crimson Kamehameha beam, a tighter gold-white Final Flash lance, a projected lightning spear from dual Asgardian weapons, a solid gold-orange Binary photon column, and green concentric thunderclap shockwave rings, all racing across the Heart of the Rift, motion-blur energy trails, [GLOBAL STYLE BLOCK]
```

### KS-7.10 — Planetary convergence ELS
**Maps to:** 7.18 · Beat C  
**Camera:** ELS 18mm locked

```
Extreme long shot of planetary scale: five tiny silhouetted heroes far below, five massive colored energy vectors converging on a colossal dark Scourge core in the Heart of an interdimensional rift, shattered planet fragments and nebula gas, blinding white magenta cyan impact blooms beginning at contact, sense of cosmic scale and doom, [GLOBAL STYLE BLOCK]
```

### KS-7.11 — Scourge cracks under first contact
**Maps to:** 7.19 · Beat C  
**Camera:** CU 85mm snap zoom

```
Close-up of the Aetherial Scourge mass: amorphous shifting void-black energy with magenta bleed, a semi-face of swirling absences, first contact of multicolor beams causing bright white cracks spiderwebbing through its body, absorbing and straining, oppressive horror beauty, extreme detail on energy texture, [GLOBAL STYLE BLOCK]
```

### KS-7.12 — Braid lock (hero plate)
**Maps to:** 7.21–7.22 · Beat D  
**Camera:** WS 35mm orbit

```
Wide cinematic climax still: five heroes’ attacks braided into one multicolor energy spear — cyan, crimson, cobalt, gold, green, lightning white — locked against a dark void entity, classic anime beam-clash geometry rendered with photoreal materials and volumetric light, heroes silhouetted at the base of the braid, reality buckling around them, [GLOBAL STYLE BLOCK]
```

### KS-7.13 — Desperation push
**Maps to:** 7.23 / 7.26 · Beat D  
**Camera:** CU handheld controlled chaos

```
Intense close cinematic still of the beam struggle impact face: heroes straining at the edge of collapse, arms shaking, auras spiking violently, teeth clenched, Kaioken red veins, Binary overload flare, Asgardian roar, Hulk emerald fury, the combined braid inching a dark Scourge toward a glowing dimensional expulsion vortex, dust and sparks, [GLOBAL STYLE BLOCK]
```

### KS-7.14 — Weak-point white core
**Maps to:** 7.28–7.29 · Beat D  
**Camera:** ECU 150mm @120fps feel

```
Extreme close-up of the point of contact: a forming blinding white weak-point core where braided multicolor energy meets void-black Scourge matter, magenta and cyan filaments peeling away, hyper-detailed energy particles frozen mid-explosion, almost abstract, pure power, [GLOBAL STYLE BLOCK]
```

### KS-7.15 — Cataclysm expulsion
**Maps to:** 7.30–7.32 · Beat E  
**Camera:** ELS 12–18mm

```
Extreme long shot cataclysm: the Aetherial Scourge ripped apart and sucked into a precise multi-dimensional expulsion vortex, white-out explosion with magenta shock-rings, planetary debris blasted outward, five faint hero silhouettes briefly readable inside the blast then lost, vortex compressing shut, Heart of the Rift collapsing, apocalyptic awe, [GLOBAL STYLE BLOCK]
```

### KS-7.16 — Aftermath spark / bridge to Scene 8
**Maps to:** 7.33 / 7.35 · Beat E–F  
**Camera:** ELS 18mm slow pull

```
Quiet extreme long shot after the blast: Heart of the Rift collapsing into eternal twilight near-black #0A0A1A, residual cyan and gold sparks drifting like dying embers, no clear figures, ringing silence visual, fragile peace after cosmic violence, cinematic negative space, [GLOBAL STYLE BLOCK]
```

---

## TRAILER CUTDOWN SET (priority render order)

1. KS-7.12 Braid lock  
2. KS-7.15 Cataclysm expulsion  
3. KS-7.02 Five heroes formation  
4. KS-7.10 Planetary convergence  
5. KS-7.04 Goku Kaioken  
6. KS-7.06 Thor storm  
7. KS-7.07 Cap Binary  
8. KS-7.08 Hulk thunderclap  
9. KS-7.01 Scourge primed  
10. KS-7.16 Aftermath spark  

## Midjourney / Flux / SDXL usage notes

- Append `--ar 21:9` or `--ar 16:9` (crop to 2.39 in Resolve).  
- Weight character identity moderately; prioritize lighting + energy readability.  
- Seed-lock within a beat for continuity (same seed family for KS-7.04 through KS-7.08).  
- Upscale 2× then light film grain; match bible grade (saturated energy, deep shadows).  

## File naming

```
KS-7.01_scourge-primed.png
KS-7.02_five-heroes-formation.png
KS-7.03_resolve-montage.png
KS-7.04_goku-kaioken-charge.png
KS-7.05_vegeta-final-flash.png
KS-7.06_thor-dual-storm.png
KS-7.07_cap-binary.png
KS-7.08_hulk-thunderclap.png
KS-7.09_signature-beams-suite.png
KS-7.10_planetary-convergence.png
KS-7.11_scourge-cracks.png
KS-7.12_braid-lock.png
KS-7.13_desperation-push.png
KS-7.14_weakpoint-core.png
KS-7.15_cataclysm-expulsion.png
KS-7.16_aftermath-spark.png
```

*Complete Scene 7 generation pack — all 16 key stills.*
